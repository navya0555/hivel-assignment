// src/main.js
const fs = require('fs');
const path = require('path');
const { obtainSecret } = require('./linearSolver');

function readJsonFromFile(relativePath) {
  const fullPath = path.join(__dirname, '..', relativePath);
  const content = fs.readFileSync(fullPath, 'utf-8');
  return JSON.parse(content);
}

function run() {
  const data1 = readJsonFromFile('cases/first.json');
  const data2 = readJsonFromFile('cases/second.json');

  const secretOne = obtainSecret(data1);
  const secretTwo = obtainSecret(data2);

  console.log(secretOne.toString());
  console.log(secretTwo.toString());
}

run();
