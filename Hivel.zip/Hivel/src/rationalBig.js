// src/rationalBig.js

function bigGcd(a, b) {
  a = a < 0n ? -a : a;
  b = b < 0n ? -b : b;

  while (b !== 0n) {
    const t = a % b;
    a = b;
    b = t;
  }
  return a;
}

class RationalBig {
  constructor(numerator, denominator = 1n) {
    if (denominator === 0n) {
      throw new Error('Denominator cannot be zero');
    }

    // normalize sign
    if (denominator < 0n) {
      numerator = -numerator;
      denominator = -denominator;
    }

    const g = bigGcd(numerator, denominator);
    this.n = numerator / g;
    this.d = denominator / g;
  }

  static from(value) {
    if (typeof value === 'bigint') {
      return new RationalBig(value, 1n);
    }
    if (typeof value === 'number') {
      return new RationalBig(BigInt(value), 1n);
    }
    throw new Error('Unsupported type for RationalBig.from');
  }

  isZero() {
    return this.n === 0n;
  }

  add(other) {
    const num = this.n * other.d + other.n * this.d;
    const den = this.d * other.d;
    return new RationalBig(num, den);
  }

  subtract(other) {
    const num = this.n * other.d - other.n * this.d;
    const den = this.d * other.d;
    return new RationalBig(num, den);
  }

  multiply(other) {
    const num = this.n * other.n;
    const den = this.d * other.d;
    return new RationalBig(num, den);
  }

  divide(other) {
    if (other.n === 0n) {
      throw new Error('Division by zero in RationalBig');
    }
    const num = this.n * other.d;
    const den = this.d * other.n;
    return new RationalBig(num, den);
  }

  toString() {
    if (this.d === 1n) return this.n.toString();
    return `${this.n.toString()}/${this.d.toString()}`;
  }
}

module.exports = {
  RationalBig
};
