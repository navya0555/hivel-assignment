// src/baseConverter.js

function symbolToValue(ch) {
  const lower = ch.toLowerCase();

  if (lower >= '0' && lower <= '9') {
    return lower.charCodeAt(0) - '0'.charCodeAt(0);
  }

  if (lower >= 'a' && lower <= 'z') {
    return 10 + (lower.charCodeAt(0) - 'a'.charCodeAt(0));
  }

  throw new Error(`Unsupported digit '${ch}'`);
}

// Convert a string in a given base to BigInt
function parseInRadix(numStr, radix) {
  const base = BigInt(radix);
  let total = 0n;

  for (const ch of numStr) {
    const digitVal = BigInt(symbolToValue(ch));
    if (digitVal >= base) {
      throw new Error(`Digit '${ch}' is invalid for base ${radix}`);
    }
    total = total * base + digitVal;
  }

  return total;
}

module.exports = {
  parseInRadix
};
