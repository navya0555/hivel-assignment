// src/linearSolver.js

const { parseInRadix } = require('./baseConverter');
const { RationalBig } = require('./rationalBig');

// Read x,y points from JSON data and keep first k points
function buildPoints(dataObject) {
  const k = dataObject.keys.k;

  const tempList = [];

  for (const key of Object.keys(dataObject)) {
    if (key === 'keys') continue;

    const xCoord = BigInt(key);
    const base = parseInt(dataObject[key].base, 10);
    const encoded = dataObject[key].value;

    const yCoord = parseInRadix(encoded, base); // BigInt

    tempList.push({ x: xCoord, y: yCoord });
  }

  // Sort by x so selection is deterministic
  tempList.sort((p, q) => (p.x < q.x ? -1 : p.x > q.x ? 1 : 0));

  const chosen = tempList.slice(0, k);

  if (chosen.length < k) {
    throw new Error('Not enough points to solve system');
  }

  return chosen;
}

// Build augmented matrix for k equations with k unknowns (degree m = k-1)
function constructAugmentedMatrix(points) {
  const k = points.length;
  const cols = k + 1; // k unknowns + 1 RHS column

  const matrix = Array.from({ length: k }, () =>
    Array.from({ length: cols }, () => new RationalBig(0n, 1n))
  );

  for (let row = 0; row < k; row++) {
    const x = points[row].x;
    const y = points[row].y;

    // compute powers of x: x^0, x^1, ..., x^{k-1}
    let xPower = 1n;
    for (let col = 0; col < k; col++) {
      matrix[row][col] = RationalBig.from(xPower);
      xPower = xPower * x;
    }

    // RHS
    matrix[row][k] = RationalBig.from(y);
  }

  return matrix;
}

// Gaussian elimination to Reduced Row Echelon Form
function solveLinearSystem(matrix) {
  const rowCount = matrix.length;
  const colCount = matrix[0].length; // k+1

  let pivotRow = 0;

  for (let pivotCol = 0; pivotCol < colCount - 1 && pivotRow < rowCount; pivotRow++, pivotCol++) {
    // 1. Find a row with a non-zero in pivotCol
    let selected = pivotRow;
    while (selected < rowCount && matrix[selected][pivotCol].isZero()) {
      selected++;
    }

    if (selected === rowCount) {
      // No pivot in this column, move to next column
      pivotRow--;
      continue;
    }

    // 2. Swap pivot row if needed
    if (selected !== pivotRow) {
      const temp = matrix[pivotRow];
      matrix[pivotRow] = matrix[selected];
      matrix[selected] = temp;
    }

    // 3. Normalize pivot row (make pivot = 1)
    const pivotVal = matrix[pivotRow][pivotCol];
    for (let c = pivotCol; c < colCount; c++) {
      matrix[pivotRow][c] = matrix[pivotRow][c].divide(pivotVal);
    }

    // 4. Eliminate this column in all other rows
    for (let r = 0; r < rowCount; r++) {
      if (r === pivotRow) continue;

      const factor = matrix[r][pivotCol];
      if (factor.isZero()) continue;

      for (let c = pivotCol; c < colCount; c++) {
        const valueToSubtract = matrix[pivotRow][c].multiply(factor);
        matrix[r][c] = matrix[r][c].subtract(valueToSubtract);
      }
    }
  }

  // Now matrix should be in RREF and last column is solution
  // unknowns: a_0, a_1, ..., a_{k-1}
  const k = rowCount;
  const solution = [];

  for (let r = 0; r < k; r++) {
    solution.push(matrix[r][colCount - 1]);
  }

  return solution;
}

// Wrapper: from raw JSON -> secret (constant term)
function obtainSecret(dataObject) {
  const pointSet = buildPoints(dataObject);
  const augmented = constructAugmentedMatrix(pointSet);
  const coefficients = solveLinearSystem(augmented);

  const constantTerm = coefficients[0]; // a_0

  if (constantTerm.d !== 1n) {
    throw new Error(
      `Constant term is not an integer: ${constantTerm.toString()}`
    );
  }

  return constantTerm.n; // BigInt
}

module.exports = {
  obtainSecret
};
